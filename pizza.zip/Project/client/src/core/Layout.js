import React from "react";
import Menu from "./Menu";

const Layout = ({
  title = "Title",
  description = "Description",
  className,
  children,
  logo = false,
}) => (
  <div>
    <Menu />
    <div className={className}>{children}</div>
  </div>
);

export default Layout;
